# JARVIS MAX 3.0

Phone-first / cloud-build Android package for the JARVIS MAX project.

## Recommended route
Use GitHub Actions from your phone to compile `app-debug.apk`. See `PHONE_ONLY_BUILD.md`.

## Features carried from MAX 2.x
- CameraX live camera preview
- ML Kit object detection
- OCR/text recognition
- Hindi/Urdu speech recognition and TTS
- Futuristic HUD overlay
- Helmet/scan mode
- Continuous user-controlled voice listening

## Build
Cloud workflow: `.github/workflows/build-apk.yml`

The workflow provisions JDK 17, Android SDK API 35/build-tools 35.0.0, Gradle 8.9, and runs `assembleDebug`.

## Security/privacy
Camera and microphone access remain permission-controlled and visible. The app is not intended for covert surveillance.

## Release builds
For a public release, configure a release signing key and build a signed release APK/AAB. Do not commit private signing keys to the repository.
