# JARVIS MAX 3.0 — Phone-only / Cloud APK Build

This package is designed so you can build the Android APK without installing Android Studio on your phone.

## What you need
- An Android phone with a browser
- A GitHub account
- Internet access

## Build from your phone
1. Open GitHub in your phone browser and create a new repository, for example `JARVIS-MAX-3.0`.
2. Upload the **contents of this folder** to the repository (not the outer ZIP folder).
3. Open the repository's **Actions** tab.
4. Select **JARVIS MAX 3.0 - Build APK**.
5. Tap **Run workflow**.
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run.
8. Under **Artifacts**, download `JARVIS-MAX-3.0-debug-APK`.
9. Extract the downloaded artifact and install `app-debug.apk` on the phone.

The workflow installs JDK 17, Android SDK platform/build tools, Gradle 8.9, and runs `assembleDebug` in a GitHub-hosted Linux runner.

## Automatic builds
A push to the `main` branch also starts the APK build automatically.

## Output
APK:
`app/build/outputs/apk/debug/app-debug.apk`

## Important
This is a debug APK intended for testing. Android requires APKs to be digitally signed; debug builds are automatically signed with the standard debug key by the Android build system. For public distribution, create a properly signed release build with your own key.

## Permissions / privacy
JARVIS MAX uses visible, permission-controlled camera and microphone features. It is not designed for covert recording or surveillance.
