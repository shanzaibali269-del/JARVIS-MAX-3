package com.jarvis.max

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.RectF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import com.google.mlkit.common.model.LocalModel
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private lateinit var preview: PreviewView
    private lateinit var hud: HudOverlay
    private lateinit var status: TextView
    private lateinit var info: TextView
    private lateinit var result: TextView
    private lateinit var tts: TextToSpeech
    private var speech: SpeechRecognizer? = null

    private val executor = Executors.newSingleThreadExecutor()
    private val active = AtomicBoolean(false)
    private var lastOcrAt = 0L
    private var lastAnnouncement = 0L
    private val mainHandler = Handler(Looper.getMainLooper())

    private val detector by lazy {
        val options = ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)
            .enableMultipleObjects()
            .enableClassification()
            .build()
        ObjectDetection.getClient(options)
    }

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        preview = findViewById(R.id.preview)
        hud = findViewById(R.id.hud)
        status = findViewById(R.id.status)
        info = findViewById(R.id.info)
        result = findViewById(R.id.result)

        tts = TextToSpeech(this, this)

        findViewById<Button>(R.id.helmet).setOnClickListener {
            if (active.get()) stopHelmet() else startHelmet()
        }

        requestPermissionsIfNeeded()
    }

    private fun requestPermissionsIfNeeded() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            needed += Manifest.permission.CAMERA
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            needed += Manifest.permission.RECORD_AUDIO
        if (needed.isNotEmpty())
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), 100)
    }

    private fun startHelmet() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissionsIfNeeded()
            return
        }
        active.set(true)
        status.text = "HELMET MAX • SCANNING ACTIVE"
        info.text = "VISION: ACTIVE\nOBJECT TRACKING: ON\nOCR: READY"
        hud.setScanning(true)
        speak("جاروس میکس ہیلمٹ موڈ فعال ہے۔ ماحولیاتی اسکین شروع کر رہا ہوں۔")
        startCamera()
        startListening()
    }

    private fun stopHelmet() {
        active.set(false)
        status.text = "SYSTEM ONLINE • HELMET READY"
        info.text = "VISION: STANDBY"
        hud.setScanning(false)
        speech?.cancel()
        speak("ہیلمٹ موڈ بند کر دیا گیا ہے۔")
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val previewUseCase = Preview.Builder().build()
            previewUseCase.setSurfaceProvider(preview.surfaceProvider)

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            analysis.setAnalyzer(executor) { proxy ->
                analyzeFrame(proxy)
            }

            provider.unbindAll()
            provider.bindToLifecycle(
                this,
                CameraSelector.DEFAULT_BACK_CAMERA,
                previewUseCase,
                analysis
            )
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyzeFrame(proxy: ImageProxy) {
        if (!active.get()) {
            proxy.close()
            return
        }
        val media = proxy.image ?: run { proxy.close(); return }
        val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)

        detector.process(image)
            .addOnSuccessListener { objects ->
                val boxes = objects.map {
                    RectF(
                        it.boundingBox.left.toFloat(),
                        it.boundingBox.top.toFloat(),
                        it.boundingBox.right.toFloat(),
                        it.boundingBox.bottom.toFloat()
                    )
                }
                runOnUiThread {
                    hud.setBoxes(boxes)
                    info.text = "VISION: ACTIVE\nOBJECTS: ${objects.size}\nTRACKING: ON"
                }

                val now = System.currentTimeMillis()
                if (objects.isNotEmpty() && now - lastAnnouncement > 6000) {
                    val label = objects.first().labels.firstOrNull()?.text
                    if (!label.isNullOrBlank()) {
                        lastAnnouncement = now
                        runOnUiThread {
                            result.text = "JARVIS: Detected $label"
                        }
                    }
                }
            }
            .addOnCompleteListener {
                proxy.close()
            }

        // OCR is throttled so it does not consume the whole CPU continuously.
        val now = System.currentTimeMillis()
        if (now - lastOcrAt > 1800) {
            lastOcrAt = now
            recognizer.process(image)
                .addOnSuccessListener { text ->
                    if (text.text.isNotBlank()) {
                        runOnUiThread {
                            result.text = "JARVIS OCR: ${text.text.take(220)}"
                        }
                    }
                }
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        speech?.destroy()
        speech = SpeechRecognizer.createSpeechRecognizer(this)
        speech?.setRecognitionListener(SimpleRecognitionListener(
            onText = { text ->
                if (text.contains("jarvis", true) || text.contains("جاروس", true)) {
                    speak("جی سر۔ میں سن رہا ہوں۔")
                }
                if (text.contains("scan", true) || text.contains("اسکین", true) || text.contains("स्कैन", true)) {
                    speak("سر، اسکین فعال ہے۔")
                }
                if (text.contains("stop", true) || text.contains("بند", true)) {
                    stopHelmet()
                }
            }
        ))
        listenOnce()
    }

    private fun listenOnce() {
        if (!active.get()) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        speech?.startListening(intent)
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_${System.currentTimeMillis()}")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val hindi = tts.setLanguage(Locale("hi", "IN"))
            if (hindi == TextToSpeech.LANG_MISSING_DATA || hindi == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.language = Locale("ur", "PK")
            }
        }
    }

    override fun onDestroy() {
        active.set(false)
        speech?.destroy()
        tts.shutdown()
        detector.close()
        recognizer.close()
        executor.shutdown()
        super.onDestroy()
    }

    private class SimpleRecognitionListener(
        val onText: (String) -> Unit
    ) : android.speech.RecognitionListener {
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text != null) onText(text)
            if (active.get()) mainHandler.postDelayed({ listenOnce() }, 250)
        }
        override fun onError(error: Int) {
            if (active.get()) mainHandler.postDelayed({ listenOnce() }, 500)
        }
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }
}
