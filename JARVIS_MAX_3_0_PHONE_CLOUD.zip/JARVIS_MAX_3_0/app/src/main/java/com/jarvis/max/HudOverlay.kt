package com.jarvis.max

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

class HudOverlay @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val boxes = mutableListOf<RectF>()
    private var scanning = false

    init {
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
    }

    fun setBoxes(newBoxes: List<RectF>) {
        boxes.clear()
        boxes.addAll(newBoxes)
        invalidate()
    }

    fun setScanning(value: Boolean) {
        scanning = value
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        p.color = Color.argb(220, 120, 255, 255)

        val cx = width / 2f
        val cy = height / 2f
        c.drawCircle(cx, cy, 90f, p)
        c.drawCircle(cx, cy, 115f, p)

        c.drawLine(cx - 145, cy, cx - 35, cy, p)
        c.drawLine(cx + 35, cy, cx + 145, cy, p)
        c.drawLine(cx, cy - 145, cx, cy - 35, p)
        c.drawLine(cx, cy + 35, cx, cy + 145, p)

        for (r in boxes) {
            c.drawRect(r, p)
            val s = 14f
            c.drawLine(r.left, r.top, r.left+s, r.top, p)
            c.drawLine(r.left, r.top, r.left, r.top+s, p)
            c.drawLine(r.right, r.bottom, r.right-s, r.bottom, p)
            c.drawLine(r.right, r.bottom, r.right, r.bottom-s, p)
        }

        if (scanning) {
            p.color = Color.argb(100, 80, 255, 255)
            c.drawRect(0f, cy - 2f, width.toFloat(), cy + 2f, p)
        }
    }
}
