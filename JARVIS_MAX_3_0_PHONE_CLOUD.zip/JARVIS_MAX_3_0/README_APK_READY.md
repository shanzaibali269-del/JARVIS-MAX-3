# JARVIS MAX — APK-READY BUILD PACKAGE

This package is organized specifically to produce an installable Android APK.

## Fastest PC build
1. Install the official Android Studio.
2. Open this folder as an existing Android/Gradle project.
3. Let Gradle sync and download dependencies.
4. Select the `debug` build variant.
5. Use **Build > Generate Bundle(s) / APK(s) > Generate APK(s)**.
6. The installable debug APK will be at:
   `app/build/outputs/apk/debug/app-debug.apk`

## Command-line build
The project targets Gradle 8.9 with Android Gradle Plugin 8.7.3.
If Gradle 8.9 is installed, run:
- Windows: `gradlew.bat :app:assembleDebug`
- Linux/macOS: `./gradlew :app:assembleDebug`

The helper scripts in `scripts/` do the same thing.

## Phone-only / cloud build
The included `.github/workflows/build-apk.yml` can build the debug APK using GitHub Actions. Upload this project to a GitHub repository, run the workflow, then download the `JARVIS-MAX-debug-APK` artifact from the workflow run.

## Important
- This ZIP is **source + build configuration**, not a precompiled APK.
- Camera and microphone operation is permission-based and visible to the user.
- The current vision stack uses CameraX + ML Kit object detection + OCR.
- It is not a literal 360-degree helmet sensor system.
- A production release APK should be signed with your own release key.
