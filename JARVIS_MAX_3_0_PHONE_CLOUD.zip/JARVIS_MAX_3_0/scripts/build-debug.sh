#!/bin/sh
set -e
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT"
./gradlew :app:assembleDebug
echo "APK: $ROOT/app/build/outputs/apk/debug/app-debug.apk"
