# 5-minute phone workflow

1. Download/extract this ZIP.
2. In your phone browser, create a GitHub repository.
3. Upload all files/folders from `JARVIS_MAX_3_0`.
4. Tap **Actions** → **JARVIS MAX 3.0 - Build APK** → **Run workflow**.
5. Wait for the green check.
6. Open the run → **Artifacts** → `JARVIS-MAX-3.0-debug-APK`.
7. Download, extract, and install `app-debug.apk`.

No Android Studio is required on the phone for this cloud-build route.
